#include <stdio.h>
#include <math.h>

using namespace std;

int main()
{
	scanf("%lf", &x)
	f();

	printf("x = %.4f\n", x);
	printf("y = %.4f\n", y);
	
	system("pause");
	return 0;
}
