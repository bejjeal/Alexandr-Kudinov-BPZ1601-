#include <math.h>

void f();
double x, y;

void f()
{
	result = 1 - (1/4 * pow(sin(2*x), 2)) + cos(2*x);
}
